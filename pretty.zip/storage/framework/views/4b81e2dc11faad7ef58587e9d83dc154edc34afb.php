
<div class="brand">Frizerski salon Pretty</div>

<div class="address-bar">Glavna cesta 24 | 4202 Naklo | 040 646 222</div>
