<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">

        <div class="container-fluid">

    <?php if(Session::has('deleted_user')): ?>


        <p class="bg-danger"><?php echo e(session('deleted_user')); ?></p> 

    <?php endif; ?>

    <h1>Uporabniki</h1>

    <table class="table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Slika</th>
            <th>Ime</th>
            <th>Email</th>
            <th>Tip</th>
            <th>Ustvarjen</th>
            <th>Posodobljen</th>
        </tr>
        </thead>
        <tbody>

        <?php if($users): ?>

            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><img height="62" src="<?php echo e($user->photo ? $user->photo->file : 'https://placeimg.com/62/62/people'); ?>" alt=""></td> 
                    <td><a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"><?php echo e($user->name); ?></a></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->role->name); ?></td>
                    <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($user->updated_at->diffForHumans()); ?></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>

        </tbody>
    </table>

            </div>
        </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>