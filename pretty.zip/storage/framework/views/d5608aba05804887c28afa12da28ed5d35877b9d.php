<div class="container">
    <div class="content">

        <?php echo Form::open(['route' => 'thumbnail.store', 'method' => 'POST', 'files' => 'true']); ?>

        <?php echo Form::label('image', 'Select Image'); ?>

        <?php echo Form::file('image', null); ?>

        <button type="submit">Upload</button>
        <?php echo Form::close(); ?>

    </div>
</div>