<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">

        <div class="container-fluid">

    <h1>Ustvari uporabnika</h1>

    <?php echo Form::open(['method'=>'POST', 'action'=>'AdminUsersController@store', 'files'=>true]); ?>


    <div class="form-group">
        <?php echo Form::label('name', 'Ime:'); ?>

        <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('email', 'Email:'); ?>

        <?php echo Form::email('email', null, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('role_id', 'Tip uporabnika:'); ?>

        <?php echo Form::select('role_id', ['Izberi možnost'] + $roles,null, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('photo_id', 'Slika:'); ?>

        <?php echo Form::file('photo_id', null, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::label('password', 'Geslo:'); ?>

        <?php echo Form::password('password', null, ['class'=>'form-control']); ?>

    </div>

    <div class="form-group">
        <?php echo Form::submit('Ustvari uporabnika', ['class'=>'btn btn-primary'] ); ?>

    </div>

    <?php echo Form::close(); ?>


    <?php echo $__env->make('includes.form_error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>