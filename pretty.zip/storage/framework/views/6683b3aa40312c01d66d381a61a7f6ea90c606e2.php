<nav class="navbar navbar-default" role="navigation">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse"
                    data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- navbar-brand is hidden on larger screens, but visible when the menu is collapsed -->
            <a class="navbar-brand" href="index.php">Frizerski salon Pretty</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                <li>
                    <a href="<?php echo e(url('/')); ?>">domov</a>
                </li>
                <li>
                    <a href="<?php echo e(url('../storitve')); ?>">storitve</a>
                </li>
                <li>
                    <a href="<?php echo e(url('../slike')); ?>">slike</a>
                </li>
                <li>
                    <a href="<?php echo e(url('../mnenja')); ?>">mnenja</a>
                </li>
                <li>
                    <a href="<?php echo e(url('../kontakt')); ?>">kontakt</a>
                </li>

                
                

                
                

                    
                <?php if($user = Auth::user()): ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo e(Auth::user()->name); ?> <b class="caret"></b></a>
                    <ul class="dropdown-menu">

                        <li class="divider"></li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"><i class="fa fa-fw fa-power-off"></i> Odjavi se</a>
                        </li>
                    </ul>
                </li>
                    <?php else: ?>

                    <li>

                    <a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-user" ></i></a>
                    </li>
                <?php endif; ?>





            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>