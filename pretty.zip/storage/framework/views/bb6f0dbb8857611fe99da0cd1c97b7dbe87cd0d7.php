<?php $__env->startSection('styles'); ?>
    <link href="../datetimepicker/build/jquery.datetimepicker.min.css" rel="stylesheet">
    <link href="../datetimepicker/jquery.datetimepicker.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">


        <div class="row">
            <div class="box">
                <div class="col-lg-12">
                    <hr>
                    <h2 class="intro-text text-center"><strong>kje nas lahko najdete</strong>
                    </h2>
                    <hr>
                </div>
                <div class="col-lg-12">
                    <div class="col-lg-8">
                        <!-- Embedded Google Map using an iframe - to select your location find it on Google maps and paste the link as the iframe src. If you want to use the Google Maps API instead then have at it! -->
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2757.8557372796145!2d14.313510015859052!3d46.27297117911882!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x477ab901e4ab7eb9%3A0xa3765354f7bf3c8d!2sFrizerski+salon+Pretty+Klara+Jenko+s.p.!5e0!3m2!1ssl!2ssi!4v1484991706110" width="600" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
                    <div class="col-lg-4">

                        <div class="business-hours">
                            <h1 class="title">Odpiralni čas</h1>
                            <ul class="list-unstyled opening-hours " style="font-size: large">
                                <li>Nedelja <span class="pull-right">Zaprto</span></li>
                                <li>Ponedeljek <span class="pull-right">11:00-19:00</span></li>
                                <li>Torek <span class="pull-right">08:00-13:00</span></li>
                                <li>Sreda <span class="pull-right">11:00-19:00</span></li>
                                <li>Četrtek <span class="pull-right">08:00-15:00</span></li>
                                <li>Petek <span class="pull-right">11:00-19:00</span></li>
                                <li>Sobota <span class="pull-right">08:00-12:00</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="container">

        <div class="row">

        <div class="box">


                <hr>
                <h2 class="intro-text text-center">
                    <strong>naročite se</strong>
                </h2>
                <hr>
            <div class="row">

                <?php echo $__env->make('includes.form_error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>

                <?php echo Form::open(['route'=>'contactus.store']); ?>


                <div class="form-group <?php echo e($errors->has('ime') ? 'has-error' : ''); ?>">
                    <?php echo Form::label('Ime in priimek:'); ?>

                    <?php echo Form::text('ime', old('ime'), ['class'=>'form-control', 'placeholder'=>'Vpiši ime']); ?>

                    
                </div>

                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                    <?php echo Form::label('Elektronski naslov:'); ?>

                    <?php echo Form::text('email', old('email'), ['class'=>'form-control', 'placeholder'=>'Vpiši elektronski naslov']); ?>

                    
                </div>

                <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                    <?php echo Form::label('Telefonska številka (neobvezno):'); ?>

                    <?php echo Form::text('phone', old('phone'), ['class'=>'form-control', 'placeholder'=>'Vpiši telefonsko številko']); ?>

                    
                </div>

            <div class="form-group <?php echo e($errors->has('termin') ? 'has-error' : ''); ?>">
               <div><label for="termin">Željeni termin:</label></div>


                    <input name="termin" id="datetimepicker7" type="datetime" class="form-control">
                    


                </div>


                <div class="form-group <?php echo e($errors->has('sporocilo') ? 'has-error' : ''); ?>">
                    <?php echo Form::label('Sporočilo:'); ?>

                    <?php echo Form::textarea('sporocilo', old('sporocilo'), ['class'=>'form-control', 'placeholder'=>'Vpiši sporočilo']); ?>

                    
                </div>

            <div class="g-recaptcha" data-sitekey="6LftVz0UAAAAABIsBONMJS7VTuHIXRU8xNPRs1dq"></div>
                <div class="form-group">
                    <button class="btn btn-success">Pošlji</button>
                </div>

                <?php echo Form::close(); ?>


            </div>


        </div>



    </div>




    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="../datetimepicker/build/jquery.datetimepicker.full.js"></script>
    <script src="../datetimepicker/build/jquery.datetimepicker.full.min.js"></script>
    <script src="../js/script.js/"></script>


    <script type="text/javascript">
        $(function () {
            $('#datetimepicker7').datetimepicker({

                dayOfWeekStart : 1,
                defaultTime:'08:00'
//                format: 'YYYY-MM-DD HH:mm'



            });
        });
    </script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>