You received a message from : <?php echo e($name); ?>


<p>
    Name: <?php echo e($name); ?>

</p>

<p>
    Email: <?php echo e($email); ?>

</p>

<p>
    Message: <?php echo e($user_message); ?>

</p>