<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">

        <div class="container-fluid">



            <h1>Sporočila</h1>

            <table class="table">
                <thead>
                <tr>
                    <th>Ime</th>
                    <th>Email</th>
                    <th>Telefonska številka</th>
                    <th>Željen termin</th>
                    <th>Sporočilo</th>
                    <th>Prejeto</th>
                    <th></th>

                </tr>
                </thead>
                <tbody>

                <?php if($contacts): ?>

                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($contact->name); ?></td>
                            <td><?php echo e($contact->email); ?></td>
                            <td><?php echo e($contact->phone); ?></td>
                            <td><?php echo e($contact->termin); ?></td>
                            <td><?php echo e($contact->message); ?></td>
                            <td><?php echo e($contact->created_at->format('d:m:Y h:m')); ?></td>
                            <td>

                                <?php if($contact->status == 1): ?>

                                    <div class="btn btn-success"> Novo

                                    </div>

                                <?php endif; ?>

                            </td>
                            <td>

                                <?php if($contact->status == 1): ?>

                                    <?php echo Form::open(['method'=>'PATCH', 'action'=>['ContactUSController@update', $contact->id]]); ?>


                                    <input type="hidden" name="status" value="0">

                                    <div class="form-group">
                                        <?php echo Form::submit('Označi kot prebrano', ['class'=>'btn btn-success'] ); ?>

                                    </div>

                                    <?php echo Form::close(); ?>



                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php endif; ?>

                </tbody>
            </table>

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>