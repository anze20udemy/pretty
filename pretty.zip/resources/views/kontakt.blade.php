
@extends('layouts.app')
@section('styles')
    <link href="../datetimepicker/build/jquery.datetimepicker.min.css" rel="stylesheet">
    <link href="../datetimepicker/jquery.datetimepicker.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">

@endsection
@section('content')
    <div class="container">


        <div class="row">
            <div class="box">
                <div class="col-lg-12">
                    <hr>
                    <h2 class="intro-text text-center"><strong>kje nas lahko najdete</strong>
                    </h2>
                    <hr>
                </div>
                <div class="col-lg-12">
                    <div class="col-lg-8">
                        <!-- Embedded Google Map using an iframe - to select your location find it on Google maps and paste the link as the iframe src. If you want to use the Google Maps API instead then have at it! -->
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2757.8557372796145!2d14.313510015859052!3d46.27297117911882!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x477ab901e4ab7eb9%3A0xa3765354f7bf3c8d!2sFrizerski+salon+Pretty+Klara+Jenko+s.p.!5e0!3m2!1ssl!2ssi!4v1484991706110" width="600" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
                    <div class="col-lg-4">

                        <div class="business-hours">
                            <h1 class="title">Odpiralni čas</h1>
                            <ul class="list-unstyled opening-hours " style="font-size: large">
                                <li>Nedelja <span class="pull-right">Zaprto</span></li>
                                <li>Ponedeljek <span class="pull-right">11:00-19:00</span></li>
                                <li>Torek <span class="pull-right">08:00-13:00</span></li>
                                <li>Sreda <span class="pull-right">11:00-19:00</span></li>
                                <li>Četrtek <span class="pull-right">08:00-15:00</span></li>
                                <li>Petek <span class="pull-right">11:00-19:00</span></li>
                                <li>Sobota <span class="pull-right">08:00-12:00</span></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <div class="container">

        <div class="row">

        <div class="box">


                <hr>
                <h2 class="intro-text text-center">
                    <strong>naročite se</strong>
                </h2>
                <hr>
            <div class="row">

                @include('includes.form_error')

            </div>

                {!! Form::open(['route'=>'contactus.store']) !!}

                <div class="form-group {{ $errors->has('ime') ? 'has-error' : '' }}">
                    {!! Form::label('Ime in priimek:') !!}
                    {!! Form::text('ime', old('ime'), ['class'=>'form-control', 'placeholder'=>'Vpiši ime']) !!}
                    {{--<span class="text-danger">{{ $errors->first('ime') }}</span>--}}
                </div>

                <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">
                    {!! Form::label('Elektronski naslov:') !!}
                    {!! Form::text('email', old('email'), ['class'=>'form-control', 'placeholder'=>'Vpiši elektronski naslov']) !!}
                    {{--<span class="text-danger">{{ $errors->first('email') }}</span>--}}
                </div>

                <div class="form-group {{ $errors->has('phone') ? 'has-error' : '' }}">
                    {!! Form::label('Telefonska številka (neobvezno):') !!}
                    {!! Form::text('phone', old('phone'), ['class'=>'form-control', 'placeholder'=>'Vpiši telefonsko številko']) !!}
                    {{--<span class="text-danger">{{ $errors->first('phone') }}</span>--}}
                </div>

            <div class="form-group {{ $errors->has('termin') ? 'has-error' : '' }}">
               <div><label for="termin">Željeni termin:</label></div>


                    <input name="termin" id="datetimepicker7" type="datetime" class="form-control">
                    {{--<span class="text-danger">{{ $errors->first('termin') }}</span>--}}


                </div>


                <div class="form-group {{ $errors->has('sporocilo') ? 'has-error' : '' }}">
                    {!! Form::label('Sporočilo:') !!}
                    {!! Form::textarea('sporocilo', old('sporocilo'), ['class'=>'form-control', 'placeholder'=>'Vpiši sporočilo']) !!}
                    {{--<span class="text-danger">{{ $errors->first('sporocilo') }}</span>--}}
                </div>

            <div class="g-recaptcha" data-sitekey="6LftVz0UAAAAABIsBONMJS7VTuHIXRU8xNPRs1dq"></div>
                <div class="form-group">
                    <button class="btn btn-success">Pošlji</button>
                </div>

                {!! Form::close() !!}

            </div>


        </div>



    </div>




    </div>
@endsection

@section('scripts')
    <script src="../datetimepicker/build/jquery.datetimepicker.full.js"></script>
    <script src="../datetimepicker/build/jquery.datetimepicker.full.min.js"></script>
    <script src="../js/script.js/"></script>


    <script type="text/javascript">
        $(function () {
            $('#datetimepicker7').datetimepicker({

                dayOfWeekStart : 1,
                defaultTime:'08:00'
//                format: 'YYYY-MM-DD HH:mm'



            });
        });
    </script>



@endsection