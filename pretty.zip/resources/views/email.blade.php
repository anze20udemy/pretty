Prejeli ste sporočilo od uporabnika : {{ $ime }}

<p>
   Telefonska številka je: {{ $phone }}
</p>

<p>
    Željeni termin : {{ $termin }}
</p>

<p>
    Njeno sporočilo se glasi: {{ $sporocilo }}
</p>