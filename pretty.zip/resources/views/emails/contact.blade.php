<h3>Dobili ste novo sporočilo preko spletnega obrazca ki vam ga je poslal/a {{$ime}}</h3>

<div>
    Njeno sporočilo se glasi:

</div>
<br>
<br>
<div>

    {{$sporocilo}}

</div>

