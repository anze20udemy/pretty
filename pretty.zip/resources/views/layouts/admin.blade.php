@include('admin.includes.header')
@include('admin.includes.navigation')

@yield('content')

@yield('scripts')

@include('admin.includes.footer')